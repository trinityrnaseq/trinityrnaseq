#!/usr/bin/env perl

use strict;
use warnings;

exit(int(rand(3)));

